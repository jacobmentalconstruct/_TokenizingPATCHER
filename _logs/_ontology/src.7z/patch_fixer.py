import json
import pyperclip # A helpful library: pip install pyperclip

# --- 1. Paste the raw components from the GPT here ---

patch_description = "Use iter_logic_ast_records in build_ast_tree_log instead of _iter_ast_nodes"

# This is the raw Python code, with NO escapes
raw_search_code = """        lines.append(_jsonl({"type": "ast_file", "path": rel}))
        for item in _iter_ast_nodes(src, rel):
            lines.append(_jsonl(item))
"""

# This is the raw Python code, with NO escapes
raw_replace_code = """        lines.append(_jsonl({"type": "ast_file", "path": rel}))
        for item in iter_logic_ast_records(src, rel):
            lines.append(_jsonl(item))
"""

# --- 2. This script builds the 100% valid JSON ---

# Create the Python dictionary
patch_data = {
  "hunks": [
    {
      "description": patch_description,
      "search_block": raw_search_code,
      "replace_block": raw_replace_code
    }
  ]
}

# Let the 'json' library handle ALL the escaping automatically
try:
    final_valid_json = json.dumps(patch_data, indent=2)
    
    # 3. The result is perfect, valid JSON
    print("--- 100% VALID JSON ---")
    print(final_valid_json)
    
    # 4. (Optional) Copy it straight to your clipboard
    pyperclip.copy(final_valid_json)
    print("\n(Copied to clipboard!)")

except Exception as e:
    print(f"An error occurred: {e}")