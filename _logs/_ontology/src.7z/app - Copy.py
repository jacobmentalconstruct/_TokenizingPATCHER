# Sturdy Patcher – Tkinter Version
# Single-file hunk patcher for one target buffer.

import tkinter as tk
from tkinter import ttk, filedialog, scrolledtext
import os
import datetime
import json
import re

# ==============================
# Global Config
# ==============================
OUTPUT_DIR = "./"
LOG_DIR = "./logs/"
LOG_TIMESTAMP_FORMAT = "%Y-%m-%d_%H-%M-%S"
DEFAULT_OUTPUT_FILENAME = "patched_output.txt"
DEBUG_EXPANDED_BY_DEFAULT = True
# ==============================

os.makedirs(LOG_DIR, exist_ok=True)

# Canonical JSON schema example for the Schema button
PATCH_SCHEMA = """{
  "hunks": [
    {
      "description": "Short human description",
      "search_block": "exact text to find\\n(can span multiple lines)",
      "replace_block": "replacement text\\n(same or different length)"
    }
  ]
}"""


class PatchError(Exception):
    """User-facing error for patch application problems."""
    pass


def detect_newline(text: str) -> str:
    """Detect whether text uses CRLF or LF."""
    if "\r\n" in text:
        return "\r\n"
    return "\n"


def split_lines_preserve(text: str, newline: str):
    """
    Split text into a list of lines on the *file's* newline,
    preserving a trailing empty line if the text ends with a newline.
    """
    if text == "":
        return [""]
    return text.split(newline)


def normalize_line_for_floating(line: str) -> str:
    """Normalize a line for floating matches (strip outer whitespace only)."""
    return line.strip()


def locate_hunk(file_lines, search_lines, floating: bool):
    """
    Return all start indices where search_lines matches file_lines.

    If floating is True, comparisons use normalize_line_for_floating;
    otherwise they are exact.
    """
    matches = []

    if not search_lines:
        return matches

    window = len(search_lines)
    max_start = len(file_lines) - window
    if max_start < 0:
        return matches

    for start in range(max_start + 1):
        ok = True
        for offset, s_line in enumerate(search_lines):
            f_line = file_lines[start + offset]
            if floating:
                if normalize_line_for_floating(f_line) != normalize_line_for_floating(s_line):
                    ok = False
                    break
            else:
                if f_line != s_line:
                    ok = False
                    break
        if ok:
            matches.append(start)

    return matches


def check_overlaps(applications):
    """Return True if any hunk application regions overlap."""
    if not applications:
        return False

    sorted_apps = sorted(applications, key=lambda a: a["start"])
    for prev, cur in zip(sorted_apps, sorted_apps[1:]):
        if prev["end"] > cur["start"]:
            return True
    return False


def apply_patch_text(file_text: str, patch_obj: dict, log_fn=None) -> str:
    """
    Apply a JSON hunk patch to file_text.

    Semantics mirror the HTML Sturdy Patcher with fixed newline handling:

    - Detect file newline (CRLF vs LF) and split file text on that.
    - Split search_block and replace_block on universal newlines (\r\n|\n).
    - Try strict matches first, then floating matches (trimmed lines) if needed.
    - Ambiguous or missing matches, or overlapping hunks, raise PatchError.
    - Hunks are applied bottom-up so earlier offsets are stable.
    """

    def log(msg: str):
        if log_fn is not None:
            log_fn(msg)

    newline = detect_newline(file_text)
    file_lines = split_lines_preserve(file_text, newline)

    hunks = patch_obj.get("hunks")
    if not isinstance(hunks, list):
        raise PatchError("Patch JSON must contain a 'hunks' array.")

    applications = []

    for idx, h in enumerate(hunks):
        num = idx + 1
        desc = h.get("description") or "(no description)"
        log(f"Hunk {num}: {desc}")

        search_block = h.get("search_block")
        replace_block = h.get("replace_block")

        if not isinstance(search_block, str) or not isinstance(replace_block, str):
            raise PatchError(f"Hunk {num} is missing search_block or replace_block.")

        # Universal newline split: patches are cross-platform
        search_lines = re.split(r"\r\n|\n", search_block)
        replace_lines = re.split(r"\r\n|\n", replace_block)

        strict_matches = locate_hunk(file_lines, search_lines, floating=False)
        if len(strict_matches) > 1:
            raise PatchError(f"Ambiguous strict match for hunk {num}.")
        if len(strict_matches) == 1:
            start = strict_matches[0]
            end = start + len(search_lines)
            log(f"Strict match at lines {start + 1}–{end}")
        else:
            float_matches = locate_hunk(file_lines, search_lines, floating=True)
            if len(float_matches) > 1:
                raise PatchError(f"Ambiguous floating match for hunk {num}.")
            if len(float_matches) == 0:
                raise PatchError(f"Hunk {num} not found in file.")
            start = float_matches[0]
            end = start + len(search_lines)
            log(f"Floating match at lines {start + 1}–{end}")

        applications.append(
            {"start": start, "end": end, "replace_lines": replace_lines}
        )

    if check_overlaps(applications):
        raise PatchError("Overlapping hunks detected. Patch aborted.")

    # Apply bottom-up so earlier offsets remain valid
    for app in sorted(applications, key=lambda a: a["start"], reverse=True):
        start = app["start"]
        end = app["end"]
        replace_lines = app["replace_lines"]
        file_lines[start:end] = replace_lines

    return newline.join(file_lines)


# Simple tooltip helper
class Tooltip:
    def __init__(self, widget, text: str):
        self.widget = widget
        self.text = text
        self.tipwindow = None
        widget.bind("<Enter>", self.show_tip)
        widget.bind("<Leave>", self.hide_tip)

    def show_tip(self, event=None):
        if self.tipwindow is not None:
            return
        x = self.widget.winfo_rootx() + 20
        y = self.widget.winfo_rooty() + 25
        self.tipwindow = tw = tk.Toplevel(self.widget)
        tw.wm_overrideredirect(True)
        tw.wm_geometry(f"+{x}+{y}")
        label = tk.Label(
            tw,
            text=self.text,
            background="#3b4252",
            foreground="#eee",
            relief="solid",
            borderwidth=1,
            font=("Segoe UI", 9),
        )
        label.pack(ipadx=4, ipady=2)

    def hide_tip(self, event=None):
        if self.tipwindow is not None:
            self.tipwindow.destroy()
            self.tipwindow = None


def create_gui():
    root = tk.Tk()
    root.title("Sturdy Patcher – Desktop Prototype")
    root.geometry("1000x750")

    # Dark theme-ish
    root.configure(bg="#020617")
    root.option_add("*Background", "#020617")
    root.option_add("*Foreground", "#e5e7eb")

    # ---------- Header ----------
    header = tk.Label(
        root,
        text="Sturdy Patcher",
        font=("Helvetica", 18, "bold"),
        bg="#020617",
        fg="#e5e7eb",
    )
    header.pack(pady=10)

    # ---------- Output filename row ----------
    filename_frame = tk.Frame(root, bg="#020617")
    filename_frame.pack(fill="x", padx=10, pady=5)

    tk.Label(
        filename_frame,
        text="Output file name:",
        bg="#020617",
        fg="#e5e7eb",
    ).pack(side="left")

    output_name_var = tk.StringVar(value=DEFAULT_OUTPUT_FILENAME)
    output_entry = tk.Entry(
        filename_frame,
        textvariable=output_name_var,
        bg="#020617",
        fg="#e5e7eb",
        insertbackground="#e5e7eb",
    )
    output_entry.pack(side="left", padx=8, fill="x", expand=True)
    Tooltip(output_entry, "Name for the patched output file (saved in OUTPUT_DIR).")

    # ---------- Toolbar ----------
    toolbar = tk.Frame(root, bg="#020617")
    toolbar.pack(fill="x", padx=10, pady=(0, 5))

    btn_load = tk.Button(toolbar, text="Load File")
    btn_load.pack(side="left", padx=5)
    Tooltip(btn_load, "Load a file from disk into the left text area.")

    btn_save = tk.Button(toolbar, text="Save Patched File")
    btn_save.pack(side="left", padx=5)
    Tooltip(btn_save, "Save patched file next to original using version fingerprint.")

    btn_clear = tk.Button(toolbar, text="Clear All")
    btn_clear.pack(side="left", padx=5)
    Tooltip(btn_clear, "Clear all text areas.")

    debug_toggle_btn = tk.Button(toolbar, text="Debug: ON")
    debug_toggle_btn.pack(side="left", padx=5)
    Tooltip(debug_toggle_btn, "Toggle debug logging.")

    # ---------- Main Paned Window ----------
    paned = tk.PanedWindow(
        root,
        orient=tk.HORIZONTAL,
        sashrelief=tk.RAISED,
        bg="#020617",
        sashwidth=4,
    )
    paned.pack(fill="both", expand=True, padx=10, pady=5)

    # Left: original file
    left_frame = tk.Frame(paned, bg="#020617")
    tk.Label(
        left_frame,
        text="Original File (Paste or Load):",
        bg="#020617",
        fg="#e5e7eb",
    ).pack(anchor="w")
    file_preview = scrolledtext.ScrolledText(
        left_frame,
        wrap=tk.NONE,
        bg="#020617",
        fg="#e5e7eb",
        insertbackground="#e5e7eb",
        borderwidth=0,
        highlightthickness=1,
        highlightbackground="#1f2937",
    )
    file_preview.pack(fill="both", expand=True)
    Tooltip(file_preview, "Paste or load the original file content here.")
    paned.add(left_frame)

    # Right: patch JSON + schema button
    right_frame = tk.Frame(paned, bg="#020617")
    patch_header = tk.Frame(right_frame, bg="#020617")
    patch_header.pack(fill="x")

    tk.Label(
        patch_header,
        text="Patch JSON Payload:",
        bg="#020617",
        fg="#e5e7eb",
    ).pack(side="left")

    schema_btn = tk.Button(patch_header, text="Schema", font=("Helvetica", 9))
    schema_btn.pack(side="right", padx=5)
    Tooltip(schema_btn, "Insert the canonical patch JSON schema.")

    patch_entry = scrolledtext.ScrolledText(
        right_frame,
        wrap=tk.NONE,
        bg="#020617",
        fg="#e5e7eb",
        insertbackground="#e5e7eb",
        borderwidth=0,
        highlightthickness=1,
        highlightbackground="#1f2937",
    )
    patch_entry.pack(fill="both", expand=True)
    Tooltip(patch_entry, "Paste your patch JSON here.")
    paned.add(right_frame)

    # ---------- Apply button ----------
    apply_frame = tk.Frame(root, bg="#020617")
    apply_frame.pack(pady=10)

    btn_apply = tk.Button(
        apply_frame,
        text="Validate and Apply Patch",
        font=("Helvetica", 12, "bold"),
        bg="#22c55e",
        fg="black",
        padx=20,
        pady=5,
    )
    btn_apply.pack()
    Tooltip(btn_apply, "Validate the patch JSON and apply to the loaded file.")

    # ---------- Debug + Status ----------
    debug_header = tk.Frame(root, bg="#020617")
    debug_header.pack(fill="x", padx=10, pady=(5, 0))

    tk.Label(
        debug_header,
        text="Debug Output:",
        bg="#020617",
        fg="#e5e7eb",
    ).pack(side="left")

    save_log_btn = tk.Button(debug_header, text="↓", font=("Helvetica", 10, "bold"))
    save_log_btn.pack(side="right", padx=5)
    Tooltip(save_log_btn, "Save debug output to log file.")

    debug_toggle = tk.Button(debug_header, text="▲", font=("Helvetica", 10, "bold"))
    debug_toggle.pack(side="right", padx=5)
    Tooltip(debug_toggle, "Show or hide debug panel.")

    debug_panel = tk.Frame(root, bg="#020617")
    debug_panel.pack(fill="both", expand=False, padx=10, pady=5)

    debug_output = scrolledtext.ScrolledText(
        debug_panel,
        wrap=tk.NONE,
        bg="#020617",
        fg="#e5e7eb",
        insertbackground="#e5e7eb",
        borderwidth=0,
        highlightthickness=1,
        highlightbackground="#1f2937",
        height=10,
    )
    debug_output.pack(fill="both", expand=True)

    status_lbl = tk.Label(root, text="Ready", fg="green", bg="#020617")
    status_lbl.pack(pady=5)

    footer = tk.Label(
        root,
        text="Sturdy Patcher – Python Edition",
        fg="gray",
        bg="#020617",
    )
    footer.pack(pady=4)

    # ---------- State + helpers ----------
    debug_enabled = tk.BooleanVar(value=True)
    debug_collapsed = tk.BooleanVar(value=not DEBUG_EXPANDED_BY_DEFAULT)

    def log(msg: str):
        if not debug_enabled.get():
            return
        debug_output.insert(tk.END, msg + "\n")
        debug_output.see(tk.END)

    def set_status(msg: str, is_error: bool = False):
        status_lbl.config(text=msg, fg=("red" if is_error else "green"))
        prefix = "ERROR: " if is_error else ""
        log(prefix + msg)

    # ---------- Command callbacks ----------

    def clear_all():
        file_preview.delete("1.0", tk.END)
        patch_entry.delete("1.0", tk.END)
        debug_output.delete("1.0", tk.END)
        set_status("Cleared", False)

    def toggle_debug_mode():
        if debug_enabled.get():
            debug_enabled.set(False)
            debug_toggle_btn.config(text="Debug: OFF")
        else:
            debug_enabled.set(True)
            debug_toggle_btn.config(text="Debug: ON")
            log("Debug mode enabled")

    def toggle_debug_panel():
        if debug_collapsed.get():
            debug_panel.pack(fill="both", expand=False, padx=10, pady=5)
            debug_toggle.config(text="▲")
            debug_collapsed.set(False)
            log("Debug panel expanded")
        else:
            debug_panel.forget()
            debug_toggle.config(text="▼")
            debug_collapsed.set(True)
            log("Debug panel collapsed")

    def save_log_to_file():
        text = debug_output.get("1.0", tk.END)
        if not text.strip():
            set_status("Debug log is empty.", True)
            return
        os.makedirs(LOG_DIR, exist_ok=True)
        stamp = datetime.datetime.now().strftime(LOG_TIMESTAMP_FORMAT)
        name = f"sturdy_patcher_log_{stamp}.txt"
        path = os.path.join(LOG_DIR, name)
        try:
            with open(path, "w", encoding="utf-8") as f:
                f.write(text)
            set_status(f"Debug log saved as {path}")
        except Exception as e:
            set_status(f"Failed to save debug log: {e}", True)

    def insert_schema():
        current = patch_entry.get("1.0", tk.END)
        if not current.strip():
            patch_entry.insert("1.0", PATCH_SCHEMA)
        else:
            patch_entry.delete("1.0", tk.END)
            patch_entry.insert("1.0", PATCH_SCHEMA)
        set_status("Schema inserted into Patch JSON area")

    def load_file():
        filepath = filedialog.askopenfilename()
        if not filepath:
            return
        try:
            with open(filepath, "r", encoding="utf-8") as f:
                file_preview.delete("1.0", tk.END)
                file_preview.insert(tk.END, f.read())
            set_status(f"Loaded: {filepath}")
        except Exception as e:
            set_status(f"Failed to load file: {e}", True)

    def save_patched_file():
        text = file_preview.get("1.0", tk.END)
        name = output_name_var.get().strip() or DEFAULT_OUTPUT_FILENAME
        os.makedirs(OUTPUT_DIR, exist_ok=True)
        out_path = os.path.join(OUTPUT_DIR, name)
        try:
            with open(out_path, "w", encoding="utf-8") as f:
                f.write(text)
            set_status(f"Patched file saved as: {out_path}")
        except Exception as e:
            set_status(f"Failed to save patched file: {e}", True)

    def apply_patch():
        set_status("Validating...", is_error=False)
        log("--- BEGIN PATCH ---")

        file_text = file_preview.get("1.0", tk.END)
        patch_text = patch_entry.get("1.0", tk.END)

        if not file_text.strip() or not patch_text.strip():
            set_status("Both file content and patch JSON must be provided.", True)
            return

        try:
            patch_obj = json.loads(patch_text)
        except Exception as e:
            set_status(f"Invalid JSON: {e}", True)
            return

        if "hunks" not in patch_obj or not isinstance(patch_obj["hunks"], list):
            set_status("Patch JSON must contain a 'hunks' array.", True)
            return

        try:
            patched = apply_patch_text(file_text, patch_obj, log_fn=log)
        except PatchError as e:
            set_status(str(e), True)
            return
        except Exception as e:
            set_status(f"Unexpected patch error: {e}", True)
            return

        file_preview.delete("1.0", tk.END)
        file_preview.insert(tk.END, patched)
        set_status("Patch Applied")
        log("--- PATCH COMPLETE ---")

    # ---------- Bind buttons / shortcuts ----------
    btn_clear.config(command=clear_all)
    debug_toggle_btn.config(command=toggle_debug_mode)
    debug_toggle.config(command=toggle_debug_panel)
    save_log_btn.config(command=save_log_to_file)
    schema_btn.config(command=insert_schema)
    btn_apply.config(command=apply_patch)
    btn_load.config(command=load_file)
    btn_save.config(command=save_patched_file)

    root.bind("<Control-o>", lambda e: load_file())
    root.bind("<Control-p>", lambda e: apply_patch())

    # Start with debug expanded or collapsed based on flag
    if DEBUG_EXPANDED_BY_DEFAULT:
        debug_collapsed.set(False)
        debug_toggle.config(text="▲")
    else:
        debug_collapsed.set(True)
        debug_panel.forget()
        debug_toggle.config(text="▼")

    root.mainloop()


if __name__ == "__main__":
    create_gui()
